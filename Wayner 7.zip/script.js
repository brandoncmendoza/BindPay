// ======================================================================
// Helper Functions for localStorage (Global o accesible a escenas)
// ======================================================================

const GAME_SAVE_DATA_KEY = 'waynerJumpAdventure_save';

function loadGameData() {
    try {
        const savedDataString = localStorage.getItem(GAME_SAVE_DATA_KEY);
        if (savedDataString) {
            const data = JSON.parse(savedDataString);
            // Asegurarse de que los datos mínimos existen, si no, usar valores por defecto
            return {
                score: data.score !== undefined ? data.score : 0,
                lives: data.lives !== undefined ? data.lives : 5,
                currentLevel: data.currentLevel !== undefined ? data.currentLevel : 1
            };
        }
    } catch (e) {
        console.error("Error al cargar datos de juego de localStorage:", e);
    }
    // Datos por defecto si no hay guardado o hay error
    return {
        score: 0,
        lives: 5,
        currentLevel: 1
    };
}

function saveGameData(data) {
    try {
        localStorage.setItem(GAME_SAVE_DATA_KEY, JSON.stringify(data));
    } catch (e) {
        console.error("Error al guardar datos de juego en localStorage:", e);
    }
}

// ======================================================================
// Scene: Preloader (Nueva escena de carga)
// ======================================================================
class Preloader extends Phaser.Scene {
    constructor() {
        super({
            key: 'Preloader'
        });
    }

    preload() {
        const loadingText = this.add.text(400, 300, 'Cargando...', {
            fontSize: '32px',
            fill: '#fff'
        }).setOrigin(0.5);

        // SOLO se carga la imagen de fondo del menú principal
        this.load.image('preloadBackground', 'assets/images/fondo_menu.png');

        this.load.on('progress', (value) => {
            loadingText.setText(`Cargando... ${Math.round(value * 100)}%`);
        });

        this.load.on('complete', () => {
            loadingText.destroy();
        });
    }

    create() {
        this.scene.start('MainMenu');
    }
}

// ======================================================================
// Scene: MainMenu (Menú Principal - Combinado con tu versión antigua y export/import)
// ======================================================================
class MainMenu extends Phaser.Scene {
    constructor() {
        super({
            key: 'MainMenu'
        });
        this.feedbackText = null; // Para mensajes de feedback de import/export
    }

    preload() {
        // La imagen de fondo del menú ya se precargó en Preloader
    }

    create() {
        this.cameras.main.setBackgroundColor('#000000'); // Fondo oscuro

        this.add.text(400, 150, 'Wayner Jump Adventure', {
            fontSize: '48px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            },
            align: 'center'
        }).setOrigin(0.5).setDepth(1);

        this.add.text(400, 220, 'creado por Wayner Esports', {
            fontSize: '18px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            },
            align: 'center'
        }).setOrigin(0.5).setDepth(1);

        this.add.text(400, 250, 'CEO: Brandon C. Mendoza', {
            fontSize: '16px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            },
            align: 'center'
        }).setOrigin(0.5).setDepth(1);

        // --- Botón Jugar (Ahora va directamente al GameMenu) ---
        const playButton = this.add.text(400, 350, 'Jugar', {
            fontSize: '32px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }).setDepth(100);

        playButton.on('pointerdown', () => {
            this.scene.start('GameMenu');
        });

        // --- Botón Exportar Progreso ---
        const exportButton = this.add.text(400, 430, 'Exportar Progreso', {
            fontSize: '24px',
            fill: '#fff',
            backgroundColor: '#4d4d00',
            padding: {
                x: 10,
                y: 6
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }).setDepth(100);

        exportButton.on('pointerdown', this.exportProgress, this);

        // --- Botón Importar Progreso ---
        const importButton = this.add.text(400, 480, 'Importar Progreso', {
            fontSize: '24px',
            fill: '#fff',
            backgroundColor: '#4d004d',
            padding: {
                x: 10,
                y: 6
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }).setDepth(100);

        importButton.on('pointerdown', this.importProgress, this);

        // Mensaje de Feedback para exportar/importar
        this.feedbackText = this.add.text(400, 530, '', {
            fontSize: '18px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            },
            align: 'center'
        }).setOrigin(0.5);
    }

    setFeedback(message, color = '#fff') {
        this.feedbackText.setText(message).setColor(color);
        this.time.delayedCall(3000, () => {
            this.feedbackText.setText('');
        });
    }

    exportProgress() {
        const gameData = loadGameData();
        const dataStr = JSON.stringify(gameData, null, 2);
        const blob = new Blob([dataStr], {
            type: "application/json"
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `wayner_jump_adventure_save_${new Date().toLocaleDateString('es-ES')}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.setFeedback('Progreso exportado como JSON.', '#00ff00');
    }

    importProgress() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'application/json';
        input.style.display = 'none';

        input.onchange = e => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    try {
                        const importedData = JSON.parse(event.target.result);
                        if (importedData && typeof importedData.score === 'number' && typeof importedData.lives === 'number' && typeof importedData.currentLevel === 'number') {
                            saveGameData(importedData);
                            this.setFeedback('Progreso importado con éxito. ¡Recarga la página para aplicar los cambios!', '#00ff00');
                        } else {
                            this.setFeedback('Archivo JSON no válido o formato incorrecto.', '#ff0000');
                        }
                    } catch (error) {
                        this.setFeedback('Error al leer el archivo JSON.', '#ff0000');
                        console.error("Error al importar progreso:", error);
                    }
                    document.body.removeChild(input);
                };
                reader.readAsText(file);
            } else {
                document.body.removeChild(input);
            }
        };

        document.body.appendChild(input);
        input.click();
        this.setFeedback('Selecciona tu archivo de progreso JSON.', '#fff');
    }
}

// ======================================================================
// Scene: GameMenu (Nueva escena que actúa como menú de juego)
// ======================================================================
class GameMenu extends Phaser.Scene {
    constructor() {
        super({
            key: 'GameMenu'
        });
    }

    create() {
        this.cameras.main.setBackgroundColor('#000000'); // Fondo oscuro

        this.add.text(400, 150, 'Menú del Juego', {
            fontSize: '48px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            },
            align: 'center'
        }).setOrigin(0.5);

        // --- Botón Jugar Nivel 1 (carga el nivel 1 con el progreso guardado) ---
        const playLevel1Button = this.add.text(400, 300, 'Jugar Nivel 1', {
            fontSize: '32px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        });

        playLevel1Button.on('pointerdown', () => {
            const gameData = loadGameData();
            // Al iniciar LevelScene, siempre pasamos level: 1 para empezar desde el principio
            // Y las vidas y el score se cargarán del localStorage que ya se reinició en gameOver
            this.scene.start('LevelScene', {
                level: 1,
                score: gameData.score,
                lives: gameData.lives
            });
        });

        // --- Botón Tienda ---
        const shopButton = this.add.text(400, 380, 'Tienda', {
            fontSize: '32px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        });

        shopButton.on('pointerdown', () => {
            const gameData = loadGameData();
            this.scene.start('Shop', {
                score: gameData.score,
                lives: gameData.lives
            });
        });

        // --- Botón Volver al Menú Principal ---
        const backButton = this.add.text(400, 500, 'Volver al Menú Principal', {
            fontSize: '24px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 15,
                y: 8
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }); // Asegura interactividad

        backButton.on('pointerdown', () => {
            this.scene.start('MainMenu');
        });
    }
}

// ======================================================================
// Scene: Shop (Tienda - Completa)
// ======================================================================
class Shop extends Phaser.Scene {
    constructor() {
        super({
            key: 'Shop'
        });
        this.playerScore = 0;
        this.playerLives = 0;
        this.scoreText = null;
    }

    init(data) {
        this.playerScore = data.score;
        this.playerLives = data.lives;
    }

    create() {
        this.cameras.main.setBackgroundColor('#444444'); // Fondo gris oscuro para la tienda

        this.add.text(400, 80, 'Tienda', {
            fontSize: '48px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            },
            align: 'center'
        }).setOrigin(0.5);

        this.scoreText = this.add.text(400, 150, `Puntos: ${this.playerScore}`, {
            fontSize: '32px',
            fill: '#FFD700',
            backgroundColor: '#000',
            padding: {
                x: 15,
                y: 8
            }
        }).setOrigin(0.5);

        // --- ÍTEM: Vida Extra (70 Puntos) ---
        this.createShopItem(
            'Vida Extra',
            70,
            'Aumenta tus vidas en 1. (Max 5)',
            300,
            () => this.buyItem('life', 70, 'Vida Extra')
        );

        // --- ÍTEM: Reiniciar Progreso ---
        this.createShopItem(
            'Reiniciar Progreso',
            -1,
            'Reinicia tu score a 0, vidas a 5 y nivel a 1. ¡Gratis!',
            380,
            () => this.buyItem('resetProgress', 0, 'Reiniciar Progreso')
        );

        // --- ÍTEM: Poción de Escudo (PRÓXIMAMENTE) ---
        this.createShopItem(
            'Poción de Escudo (PRÓXIMAMENTE)',
            200,
            'Te da un escudo temporal de 3 segundos contra los enemigos.',
            460,
            () => {
                const feedbackText = this.add.text(400, this.sys.game.config.height - 100, '¡Próximamente! Esta función aún no está disponible.', {
                    fontSize: '24px',
                    fill: '#ff0',
                    backgroundColor: '#000',
                    padding: {
                        x: 10,
                        y: 5
                    },
                    align: 'center'
                }).setOrigin(0.5).setDepth(200);
                this.time.delayedCall(2000, () => {
                    feedbackText.destroy();
                });
            },
            true
        );

        // --- Botón Volver al Menú del Juego ---
        const backButton = this.add.text(400, 550, 'Volver al Menú del Juego', {
            fontSize: '28px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 15,
                y: 8
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }); // Asegura interactividad

        backButton.on('pointerdown', () => {
            this.scene.start('GameMenu'); // Vuelve al GameMenu
        });
    }

    createShopItem(name, cost, description, yPos, callback, disabled = false) {
        const itemContainer = this.add.container(400, yPos);

        const itemBg = this.add.rectangle(0, 0, 600, 80, 0x222222)
            .setStrokeStyle(2, disabled ? 0x888888 : 0xaaaaaa);
        itemContainer.add(itemBg);

        const itemText = this.add.text(-250, -25, `${name} (${cost === -1 ? 'GRATIS' : `${cost} Pts`})`, {
            fontSize: '24px',
            fill: disabled ? '#888888' : '#fff'
        }).setOrigin(0, 0.5);
        itemContainer.add(itemText);

        const descText = this.add.text(-250, 15, description, {
            fontSize: '16px',
            fill: disabled ? '#aaaaaa' : '#ccc'
        }).setOrigin(0, 0.5);
        itemContainer.add(descText);

        const buyButton = this.add.text(250, 0, disabled ? 'Próximamente' : 'Comprar', {
            fontSize: '24px',
            fill: disabled ? '#888888' : '#00ff00',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            }
        }).setOrigin(1, 0.5).setInteractive(!disabled ? {
            useHandCursor: true
        } : {}); // Asegura interactividad
        itemContainer.add(buyButton);

        buyButton.on('pointerdown', callback);
    }

    buyItem(itemId, cost, itemName) {
        let message = '';
        let success = false;
        let gameData = loadGameData();

        switch (itemId) {
            case 'life':
                if (gameData.score >= cost) {
                    if (gameData.lives < 5) {
                        gameData.score -= cost;
                        gameData.lives++;
                        message = `¡Compraste ${itemName}! Vidas: ${gameData.lives}`;
                        success = true;
                    } else {
                        message = '¡Ya tienes el máximo de vidas (5)!';
                    }
                } else {
                    message = `¡No tienes suficientes puntos para ${itemName}! Necesitas ${cost} Pts.`;
                }
                break;
            case 'resetProgress':
                gameData.score = 0;
                gameData.lives = 5;
                gameData.currentLevel = 1;
                message = '¡Progreso reiniciado! ¡Que empiece la nueva aventura!';
                success = true;
                break;
            default:
                message = 'Ítem no reconocido.';
        }

        if (success) {
            saveGameData(gameData);
            this.playerScore = gameData.score;
            this.playerLives = gameData.lives;
        }
        this.scoreText.setText(`Puntos: ${this.playerScore}`);

        const feedbackText = this.add.text(400, this.sys.game.config.height - 100, message, {
            fontSize: '24px',
            fill: success ? '#00ff00' : '#ff0000',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            },
            align: 'center'
        }).setOrigin(0.5).setDepth(200);

        this.time.delayedCall(2000, () => {
            feedbackText.destroy();
        });
    }
}

// ======================================================================
// Scene: LevelSelection (Tu escena antigua de selección de nivel)
// ======================================================================
class LevelSelection extends Phaser.Scene {
    constructor() {
        super({
            key: 'LevelSelection'
        });
    }
    preload() {
        // No hay precarga de imágenes aquí
    }
    create() {
        this.cameras.main.setBackgroundColor('#000000'); // Fondo oscuro para esta escena
        this.add.text(400, 50, 'Selecciona un Nivel', {
            fontSize: '40px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 20,
                y: 10
            }
        }).setOrigin(0.5);

        const buttonWidth = 150;
        const buttonHeight = 80;
        const columns = 2;
        const rows = 5;
        const padding = 20;
        for (let i = 0; i < 10; i++) {
            const col = i % columns;
            const row = Math.floor(i / columns);
            const x = 300 + col * (buttonWidth + padding);
            const y = 150 + row * (buttonHeight + padding);
            const difficulty = ['Fácil', 'Normal', 'Difícil', 'Muy Difícil', 'Experto'][Math.floor(i / 2)];

            const levelButton = this.add.container(x, y);

            const buttonBg = this.add.rectangle(0, 0, buttonWidth, buttonHeight, 0x000000)
                .setInteractive({
                    useHandCursor: true
                }) // Asegura interactividad
                .on('pointerdown', () => {
                    const gameData = loadGameData(); // Cargar datos para pasar al nivel
                    this.startLevel(i + 1, gameData.score, gameData.lives);
                });

            const levelText = this.add.text(0, -15, `Nivel ${i + 1}`, {
                fontSize: '24px',
                fill: '#fff'
            }).setOrigin(0.5);

            const difficultyText = this.add.text(0, 15, difficulty, {
                fontSize: '18px',
                fill: '#fff'
            }).setOrigin(0.5);

            levelButton.add([buttonBg, levelText, difficultyText]);
        }
        // Botón para volver al menú principal
        const backButton = this.add.text(400, 550, 'Volver al Menú', {
            fontSize: '24px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 15,
                y: 8
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }); // Asegura interactividad
        backButton.on('pointerdown', () => {
            this.scene.start('MainMenu');
        });
    }
    // startLevel ahora pasa score y lives
    startLevel(level, score, lives) {
        this.scene.start('LevelScene', {
            level: level,
            score: score,
            lives: lives
        });
    }
}

// ======================================================================
// Scene: LevelScene (Restaurada a la estructura anterior para evitar congelación)
// ======================================================================
class LevelScene extends Phaser.Scene {
    constructor() {
        super({
            key: 'LevelScene'
        });
        this.isMobile = false;
        this.joystick = { // Se mantiene la estructura del joystick para móvil
            base: null,
            stick: null,
            active: false,
            pointerId: null,
            direction: 0
        };
        this.initialScoreForLevel = 0; // Para el sistema de vida extra

        this.player = null; // ¡Este será el rectángulo del jugador directamente!
        this.platforms = null;
        this.enemies = null;
        this.coins = null;
        this.levelExit = null; // Rectángulo para pasar de nivel
        this.jumps = 0;
        this.cursors = null;
        this.spaceKey = null;
        this.keyA = null;
        this.keyD = null;
        this.scoreText = null;
        this.lifeIcons = []; // Usamos iconos, no un texto de vidas
        this.scoreForNextLife = 100; // Para calcular la siguiente vida extra
        this.playerIsInvincible = false; // Para la invencibilidad después de recibir daño

        this.enemyJumpTimers = []; // Para almacenar los timers de salto de los enemigos

        // Nueva propiedad para el radio del joystick
        this.joystickRadius = 50;
    }

    init(data) {
        this.isMobile = this.sys.game.device.os.android ||
            this.sys.game.device.os.iOS ||
            this.sys.game.device.os.iPad ||
            this.sys.game.device.os.iPhone ||
            this.sys.game.device.os.kindle ||
            this.sys.game.device.os.windowsPhone;

        // Carga el score y las vidas del progreso global/de la data pasada
        this.score = data.score !== undefined ? data.score : 0;
        this.lives = data.lives !== undefined ? data.lives : 5;
        this.currentLevel = data.level !== undefined ? data.level : 1;
    }

    preload() {
        // No cargamos imágenes aquí, todo será con formas geométricas
    }

    create(data) {
        // Limpiar timers de enemigos de una partida anterior
        this.enemyJumpTimers.forEach(timer => timer.remove());
        this.enemyJumpTimers = [];

        const currentLevel = this.currentLevel;

        this.totalCoinsInLevel = 0; // Se usará para saber cuántas monedas hay en el nivel
        this.collectedCoinsInLevel = 0; // Se usará para saber cuántas monedas se han recogido
        this.initialScoreForLevel = this.score;

        // Reiniciar scoreForNextLife al inicio de cada nivel o cuando se carga el progreso
        this.scoreForNextLife = 100 * (Math.floor(this.score / 100) + 1);
        if (this.lives >= 5) { // Si ya tiene 5 vidas, no necesita más por score
            this.scoreForNextLife = Infinity;
        }

        // Fondo del nivel (color sólido)
        this.cameras.main.setBackgroundColor('#87CEEB'); // Color azul cielo

        // Crear grupos de física (usarán cuerpos de física)
        this.platforms = this.physics.add.staticGroup();
        this.coins = this.physics.add.group();
        this.enemies = this.physics.add.group();

        // Generar el nivel con formas geométricas
        this.generateRandomLevel(currentLevel);

        // Crear el jugador (rectángulo rojo)
        this.player = this.add.rectangle(100, 450, 32, 48, 0xFF0000);
        this.physics.add.existing(this.player); // Le añade el cuerpo de física

        this.player.body.setBounce(0.2);
        this.player.body.setCollideWorldBounds(true);


        // Colisiones
        this.physics.add.collider(this.player, this.platforms);
        this.physics.add.collider(this.enemies, this.platforms);
        this.physics.add.collider(this.coins, this.platforms); // Monedas colisionan con plataformas
        this.physics.add.collider(this.coins, this.coins); // Monedas entre sí (opcional)

        this.physics.add.overlap(this.player, this.coins, this.collectCoin, null, this);
        // Colisión con enemigo: Ahora usa un callback específico que maneja el "pisoteo"
        this.physics.add.collider(this.player, this.enemies, this.handlePlayerEnemyCollision, null, this);
        // Nueva colisión con el objetivo de nivel
        this.physics.add.overlap(this.player, this.levelExit, this.levelComplete, null, this);


        this.updateLifeUI(); // Actualiza los iconos de vida

        this.add.text(400, 50, `Nivel ${currentLevel}`, {
            fontSize: '32px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            }
        }).setOrigin(0.5);

        // Botón para volver al Menú del Juego
        const gameMenuButton = this.add.text(750, 50, 'Menú', {
            fontSize: '24px',
            fill: '#fff',
            backgroundColor: '#000',
            padding: {
                x: 10,
                y: 5
            }
        }).setOrigin(0.5).setInteractive({
            useHandCursor: true
        }); // Asegura interactividad
        gameMenuButton.on('pointerdown', () => {
            saveGameData({
                score: this.score,
                lives: this.lives,
                currentLevel: this.currentLevel // Guardamos el nivel que estaba jugando
            });
            // Al volver al menú, detenemos esta escena para asegurar limpieza
            this.scene.stop('LevelScene');
            this.scene.start('GameMenu'); // Vuelve al GameMenu
        });

        // Controles de teclado
        this.cursors = this.input.keyboard.createCursorKeys();
        this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        this.keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        this.keyD = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

        this.input.addPointer(1); // Permite hasta 2 toques simultáneos

        if (this.isMobile) {
            this.createMobileControls();
        }

        // Texto de puntuación
        this.scoreText = this.add.text(16, 16, 'Score: ' + this.score, {
            fontSize: '32px',
            fill: '#fff',
            backgroundColor: '#000'
        }).setScrollFactor(0);

        // Mover la cámara después de que el jugador ha sido creado
        this.cameras.main.startFollow(this.player, true, 0.05, 0.05);
        this.cameras.main.setBounds(0, 0, this.physics.world.bounds.width, this.physics.world.bounds.height);
    }

    generateRandomLevel(level) {
        this.platforms.clear(true, true);
        this.enemies.clear(true, true);
        this.coins.clear(true, true);
        // Asegúrate de destruir el levelExit anterior si existe
        if (this.levelExit) {
            this.levelExit.destroy();
            this.levelExit = null;
        }

        this.totalCoinsInLevel = 0;
        this.collectedCoinsInLevel = 0;

        // Suelo (rectángulo marrón estático)
        const ground = this.add.rectangle(400, 568, 800, 64, 0x8B4513); // Color MARRÓN
        this.platforms.add(ground);
        ground.body.allowGravity = false;
        ground.body.immovable = true;
        this.platforms.refresh(); // Importante para actualizar los cuerpos de física de los rectángulos

        const platformYStart = 450;
        const platformYSpacing = 80;
        const numPlatforms = 3 + level;
        // Lógica de enemigos: Nivel 1 = 4, Nivel 2 = 5, Nivel 3 = 6, etc. (nivel + 3) hasta el nivel 20
        let numEnemiesInLevel = 0;
        if (level <= 20) { // Aplicar la regla hasta el nivel 20
            numEnemiesInLevel = level + 3;
        } else { // Para niveles superiores al 20, mantener el número del nivel 20 o una cantidad máxima
            numEnemiesInLevel = 23; // Nivel 20 + 3 = 23 enemigos
        }

        const numCoins = 5 + level * 2;

        // Plataformas aleatorias (rectángulos grises estáticos)
        for (let i = 0; i < numPlatforms; i++) {
            const x = Phaser.Math.Between(100, 700);
            const y = platformYStart - (i * platformYSpacing) - (Phaser.Math.Between(0, 30));
            const platform = this.add.rectangle(x, y, 200, 32, 0x888888);
            this.platforms.add(platform);
            platform.body.allowGravity = false;
            platform.body.immovable = true;
            this.platforms.refresh();
        }

        // Enemigos (rectángulos morados con cuerpos de física que saltan y se mueven)
        for (let i = 0; i < numEnemiesInLevel; i++) {
            const x = Phaser.Math.Between(100, 700);
            const y = Phaser.Math.Between(0, 100);

            const enemy = this.enemies.create(x, y, null);
            enemy.setSize(32, 32); // Tamaño del cuerpo de física para el rectángulo
            enemy.setTint(0x800080); // Color MORADO (violeta) para el enemigo
            enemy.setOrigin(0.5);

            enemy.body.setBounce(1); // Los enemigos rebotan completamente
            enemy.body.setCollideWorldBounds(true); // Rebotan en los límites del mundo
            enemy.setVelocityX(Phaser.Math.Between(-100, 100)); // Velocidad inicial horizontal aleatoria
            enemy.body.onWorldBounds = true;

            // Timer para saltar aleatoriamente
            const jumpTimer = this.time.addEvent({
                delay: Phaser.Math.Between(1000, 3000), // Salta cada 1-3 segundos
                callback: () => {
                    // Solo salta si está tocando el suelo o una plataforma
                    if (enemy.body && (enemy.body.blocked.down || enemy.body.touching.down)) {
                        enemy.setVelocityY(-Phaser.Math.Between(150, 300)); // Salto aleatorio
                    }
                },
                callbackScope: this,
                loop: true
            });
            this.enemyJumpTimers.push(jumpTimer); // Guardar el timer para poder eliminarlo después
        }

        // Monedas (círculos amarillos con cuerpos de física que caen y colisionan)
        for (let i = 0; i < numCoins; i++) {
            // Genera más arriba para que caigan
            const coin = this.add.circle(Phaser.Math.Between(100, 700), Phaser.Math.Between(50, 150), 10, 0xFFD700);
            this.physics.add.existing(coin);
            this.coins.add(coin); // Añade la moneda al grupo de monedas

            coin.body.setCircle(10); // Asegura que el cuerpo de física es un círculo
            coin.body.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
            coin.body.setCollideWorldBounds(true); // Las monedas también rebotan en el mundo
            this.totalCoinsInLevel++;
        }

        // Rectángulo azul para pasar de nivel (ESTÁTICO, en la esquina superior derecha, debajo del menú)
        const exitWidth = 50;
        const exitHeight = 25; // Altura de 25 para hacerlo rectangular
        const exitX = this.sys.game.config.width - (exitWidth / 2) - 10; // 10px desde el borde derecho
        const exitY = 100; // Posición Y debajo del botón de menú (que está a 50px de la parte superior)

        this.levelExit = this.add.rectangle(exitX, exitY, exitWidth, exitHeight, 0x0000FF); // Tamaño y color AZUL
        this.physics.add.existing(this.levelExit);
        this.levelExit.body.allowGravity = false; // No le afecta la gravedad
        this.levelExit.body.setImmovable(true); // Es estático
        this.levelExit.setAlpha(0.7); // Un poco transparente para distinguirlo
        this.levelExit.setDepth(10); // Asegura que esté por encima de las plataformas pero no del texto UI

    }

    // Actualiza la interfaz de usuario de las vidas (círculos ROJOS)
    updateLifeUI() {
        this.lifeIcons.forEach(icon => icon.destroy());
        this.lifeIcons = [];

        for (let i = 0; i < this.lives; i++) {
            const lifeIcon = this.add.circle(650 + (i * 30), 30, 10, 0xFF0000) // Color ROJO (0xFF0000)
                .setScrollFactor(0)
                .setDepth(100);
            this.lifeIcons.push(lifeIcon);
        }
    }

    // Creación de controles móviles (Joystick y botón de salto)
    createMobileControls() {
        // Usamos this.joystickRadius que está declarado en el constructor de la escena
        const joystickX = this.joystickRadius + 40;
        const joystickY = this.sys.game.config.height - this.joystickRadius - 40;

        this.joystick.base = this.add.circle(joystickX, joystickY, this.joystickRadius, 0x0000ff, 0.5)
            .setScrollFactor(0)
            .setDepth(100);
        this.joystick.stick = this.add.circle(joystickX, joystickY, this.joystickRadius * 0.6, 0x0000ff, 0.8)
            .setScrollFactor(0)
            .setDepth(101);

        this.joystick.base.setInteractive({
            useHandCursor: true
        });
        this.joystick.base.on('pointerdown', (pointer) => {
            if (!this.jumpButton || !this.jumpButton.getBounds().contains(pointer.x, pointer.y)) {
                this.joystick.active = true;
                this.joystick.pointerId = pointer.id;

                const distance = Phaser.Math.Distance.Between(this.joystick.base.x, this.joystick.base.y, pointer.x, pointer.y);
                if (distance < this.joystickRadius) {
                    this.joystick.stick.x = pointer.x;
                    this.joystick.stick.y = pointer.y;
                } else {
                    const angle = Phaser.Math.Angle.Between(this.joystick.base.x, this.joystick.base.y, pointer.x, pointer.y);
                    this.joystick.stick.x = this.joystick.base.x + Math.cos(angle) * this.joystickRadius;
                    this.joystick.stick.y = this.joystick.base.y + Math.sin(angle) * this.joystickRadius;
                }

                if (this.joystick.stick.x < this.joystick.base.x - this.joystickRadius * 0.2) {
                    this.joystick.direction = -1;
                } else if (this.joystick.stick.x > this.joystick.base.x + this.joystickRadius * 0.2) {
                    this.joystick.direction = 1;
                }
            }
        });

        this.input.on('pointermove', (pointer) => {
            if (this.joystick.active && pointer.id === this.joystick.pointerId) {
                const angle = Phaser.Math.Angle.Between(this.joystick.base.x, this.joystick.base.y, pointer.x, pointer.y);
                const distance = Phaser.Math.Distance.Between(this.joystick.base.x, this.joystick.base.y, pointer.x, pointer.y);

                if (distance < this.joystickRadius) {
                    this.joystick.stick.x = pointer.x;
                    this.joystick.stick.y = pointer.y;
                } else {
                    this.joystick.stick.x = this.joystick.base.x + Math.cos(angle) * this.joystickRadius;
                    this.joystick.stick.y = this.joystick.base.y + Math.sin(angle) * this.joystickRadius;
                }

                if (pointer.x < this.joystick.base.x - this.joystickRadius * 0.2) {
                    this.joystick.direction = -1;
                } else if (pointer.x > this.joystick.base.x + this.joystickRadius * 0.2) {
                    this.joystick.direction = 1;
                } else {
                    this.joystick.direction = 0;
                }
            }
        });

        this.input.on('pointerup', (pointer) => {
            if (this.joystick.active && pointer.id === this.joystick.pointerId) {
                this.joystick.active = false;
                this.joystick.pointerId = null;
                this.joystick.stick.setPosition(this.joystick.base.x, this.joystick.base.y);
                this.joystick.direction = 0;
            }
        });

        const jumpButtonSize = 80;
        const jumpButtonX = this.sys.game.config.width - jumpButtonSize / 2 - 40;
        const jumpButtonY = this.sys.game.config.height - jumpButtonSize / 2 - 40;

        this.jumpButton = this.add.circle(jumpButtonX, jumpButtonY, jumpButtonSize / 2, 0xff0000, 0.7)
            .setInteractive({
                useHandCursor: true
            })
            .setScrollFactor(0)
            .setDepth(100);
        this.add.text(jumpButtonX, jumpButtonY, '↑', {
            fontSize: '40px',
            fill: '#fff'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(101);

        this.jumpButtonPressed = false;
        this.lastJumpButtonPressed = false;

        this.jumpButton.on('pointerdown', () => {
            this.jumpButtonPressed = true;
        });
        this.jumpButton.on('pointerup', () => {
            this.jumpButtonPressed = false;
        });
        this.jumpButton.on('pointerout', () => {
            this.jumpButtonPressed = false;
        });
    }

    update() {
        let setPlayerVelocityX = 0;

        // Lógica de movimiento para teclado y joystick móvil
        if (this.isMobile) {
            if (this.joystick.active) {
                if (this.joystick.direction === -1) {
                    setPlayerVelocityX = -160;
                } else if (this.joystick.direction === 1) {
                    setPlayerVelocityX = 160;
                } else {
                    setPlayerVelocityX = 0;
                }
            } else {
                setPlayerVelocityX = 0;
            }
        } else {
            if (this.keyA.isDown || this.cursors.left.isDown) {
                setPlayerVelocityX = -160;
            } else if (this.keyD.isDown || this.cursors.right.isDown) {
                setPlayerVelocityX = 160;
            } else {
                setPlayerVelocityX = 0;
            }
        }
        this.player.body.setVelocityX(setPlayerVelocityX);

        // Lógica de salto (doble salto)
        if (this.player.body.touching.down) {
            this.jumps = 0;
        }

        const didPressJump = Phaser.Input.Keyboard.JustDown(this.spaceKey) ||
            (this.isMobile && this.jumpButtonPressed && !this.lastJumpButtonPressed);

        if (didPressJump && this.jumps < 2) {
            this.player.body.setVelocityY(-400);
            this.jumps++;
        }

        if (this.isMobile) {
            this.lastJumpButtonPressed = this.jumpButtonPressed;
        }

        // Movimiento y actualización de posición visual de los enemigos
        this.enemies.children.iterate((enemy) => {
            // Lógica de movimiento de los enemigos (rebotan en los bordes)
            if (enemy.body.blocked.left || enemy.body.blocked.right) {
                enemy.setVelocityX(-enemy.body.velocity.x);
            }
            if (enemy.body.velocity.x === 0) {
                // Previene que el enemigo se quede quieto, le da una nueva dirección
                enemy.setVelocityX(Phaser.Math.Between(-100, 100));
            }
        });

        // Fin del juego si las vidas llegan a cero
        if (this.lives <= 0) {
            this.gameOver();
        }
    }

    // Recolección de monedas
    collectCoin(player, coin) {
        if (coin.body && coin.active) {
            this.coins.remove(coin, true, true); // remove(child, destroyChild, removeFromParent)
        } else {
            console.warn("Coin or its body was already inactive/destroyed, skipping collect:", coin);
            return;
        }

        this.score += 10;
        this.collectedCoinsInLevel++; // Incrementa las monedas recogidas en el nivel
        this.scoreText.setText('Score: ' + this.score);

        // Otorgar vida extra si se alcanza el umbral de puntuación y no se tiene el máximo de vidas
        if (this.lives < 5 && this.score >= this.scoreForNextLife) {
            this.lives++;
            this.updateLifeUI(); // Actualiza los íconos de vida
            this.scoreForNextLife += 100; // Siguiente umbral para vida extra

            const lifeText = this.add.text(player.x, player.y - 50, '¡Vida Extra!', {
                fontSize: '20px',
                fill: '#00FF00',
                backgroundColor: '#000',
                padding: {
                    x: 5,
                    y: 3
                }
            }).setOrigin(0.5);
            this.tweens.add({
                targets: lifeText,
                y: lifeText.y - 30,
                alpha: 0,
                duration: 1500,
                ease: 'Power1',
                onComplete: () => lifeText.destroy()
            });
        }
    }

    // NUEVA FUNCIÓN: Maneja la colisión entre el jugador y un enemigo
    handlePlayerEnemyCollision(player, enemy) {
        if (this.playerIsInvincible) {
            return;
        }

        // Determinar si el jugador ha "pisado" al enemigo
        // Comprobamos si el jugador está cayendo Y si el borde inferior del jugador está encima
        // del borde superior del enemigo (con un pequeño margen para precisión)
        const stompMargin = 5; // Un pequeño margen para que el "pisoteo" sea más indulgente
        if (player.body.velocity.y > 0 && player.body.bottom <= enemy.body.top + stompMargin) {
            // El jugador ha pisado la cabeza del enemigo
            enemy.disableBody(true, true); // Deshabilita y destruye el GameObject del enemigo
            player.setVelocityY(-200); // Pequeño rebote para el jugador
            this.score += 50; // Puntos por eliminar enemigo
            this.scoreText.setText('Score: ' + this.score);
        } else {
            // El enemigo golpea al jugador por los lados o desde abajo
            this.lives--; // Pierde una vida
            this.updateLifeUI(); // Actualiza los íconos de vida

            this.playerIsInvincible = true; // El jugador se vuelve invencible temporalmente
            this.player.fillColor = 0x888888; // Cambia el color del jugador a gris

            this.time.delayedCall(1500, () => { // Después de 1.5 segundos
                this.player.fillColor = 0xFF0000; // Vuelve al color rojo original
                this.playerIsInvincible = false; // Quita la invencibilidad
            }, [], this);

            if (this.lives <= 0) { // Si no quedan vidas, Game Over
                this.gameOver();
            } else {
                this.player.setPosition(100, 450); // Mueve al jugador de vuelta a una posición segura
            }
        }
    }

    // Nivel completado (ahora se activa al tocar el rectángulo azul)
    levelComplete(player, levelExit) {
        // Aseguramos que solo se active una vez
        if (this.scene.isActive('LevelScene') && this.levelExit && this.levelExit.active) {

            // Obtenemos el nivel desbloqueado actual desde localStorage y lo actualizamos
            let gameData = loadGameData();
            // Aseguramos que el nivel actual en los datos guardados no sea menor al que se está jugando
            const nextUnlockedLevel = Math.max(gameData.currentLevel, this.currentLevel + 1);

            saveGameData({
                score: this.score,
                lives: this.lives,
                currentLevel: nextUnlockedLevel // Guarda el nuevo nivel desbloqueado
            });

            this.add.text(400, 300, `¡Nivel ${this.currentLevel} Completado!`, {
                fontSize: '64px',
                fill: '#00ff00',
                backgroundColor: '#000',
                padding: {
                    x: 30,
                    y: 15
                }
            }).setOrigin(0.5).setDepth(200);

            // Destruimos el objetivo de nivel para que no cause problemas en la siguiente escena
            if (this.levelExit) {
                this.levelExit.destroy(); // Esto destruye el objeto visual y su cuerpo de física
                this.levelExit = null; // Limpiamos la referencia
            }
            // Eliminamos la pausa de la física aquí para una transición más fluida

            // Limpiar timers de enemigos antes de cambiar de escena
            this.enemyJumpTimers.forEach(timer => timer.remove());
            this.enemyJumpTimers = [];

            this.time.delayedCall(3000, () => { // Después de 3 segundos, inicia el siguiente nivel
                // Detenemos la escena actual antes de iniciar la siguiente para una limpieza completa
                this.scene.stop('LevelScene');
                this.scene.start('LevelScene', {
                    level: this.currentLevel + 1, // Pasa el siguiente nivel
                    score: this.score,
                    lives: this.lives,
                });
            });
        }
    }

    // Fin del juego (Game Over)
    gameOver() {
        // Aseguramos que solo se active una vez
        if (this.scene.isActive('LevelScene')) {
            // Guarda el estado final del jugador (vidas 0 y reiniciar nivel a 1)
            saveGameData({
                score: this.score,
                lives: 0,
                currentLevel: 1 // Si es Game Over, el nivel actual vuelve a 1
            });

            this.physics.pause(); // Pausa la física del juego (esto sí lo dejamos para Game Over)

            this.add.text(400, 300, '¡GAME OVER!', {
                fontSize: '72px',
                fill: '#ff0000',
                backgroundColor: '#000',
                padding: {
                    x: 40,
                    y: 20
                }
            }).setOrigin(0.5).setDepth(200);

            // Limpiar timers de enemigos antes de cambiar de escena
            this.enemyJumpTimers.forEach(timer => timer.remove());
            this.enemyJumpTimers = [];

            this.time.delayedCall(4000, () => { // Después de 4 segundos, vuelve al menú principal
                // Detenemos la escena actual antes de iniciar la siguiente para una limpieza completa
                this.scene.stop('LevelScene');
                this.scene.start('MainMenu');
            });
        }
    }
}


// ======================================================================
// Phaser Game Configuration
// ======================================================================
const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container',
    dom: {
        createContainer: true
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: {
                y: 300
            },
            debug: false // Puedes ponerlo en true para ver los cuerpos de física durante el desarrollo
        }
    },
    scene: [Preloader, MainMenu, GameMenu, Shop, LevelSelection, LevelScene],
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        fullscreenTarget: 'game-container',
    }
};

// Inicializa el juego
const game = new Phaser.Game(config);

// Función para activar pantalla completa (no se activa automáticamente, solo si la llamas)
function enableFullscreen() {
    const element = document.documentElement;
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
}